#include <iostream>
#include <vector>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shaders.h"
#include "VAO.h"
#include "VBO.h"
#include "EBO.h"
#include "texture.h"
#include "camera.h"


GLfloat vertices[] = {
    0.0f, 0.0f, 0.0f,     0.0f, 1.0f,
    1.0f, 0.0f, 0.0f,     0.5f, 1.0f,
    1.0f, 0.0f, 1.0f,     0.5f, 0.5f,
    0.0f, 0.0f, 1.0f,     0.0f, 0.5f
};

GLuint indices[] = {
    0, 1, 2,
    2, 3, 0
};

int main()
{
    #pragma region "Initialization and creation of the context and the window"

    if (!glfwInit())
    {
        std::cerr << "Failed to init GLFW" << std::endl;
        return -1;
    }

    // Dire à GLFW quelle version d'openGL utiliser, ici on utilise openGL 3.3 
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    // Dire à GLFW qu'on utlise le CORE_PROFILE, donc que les fonctions modernes
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWmonitor* primMonitor = glfwGetPrimaryMonitor();

    const GLFWvidmode* mode = glfwGetVideoMode(primMonitor);

    int WIDTH = mode->width;
    int HEIGHT = mode->height;

    GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "Minecraft", primMonitor, NULL);

    if (window == NULL)
    {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);

    if (glewInit() != GLEW_OK)
    {
        std::cerr << "Failed to init GLEW" << std::endl;
        glfwDestroyWindow(window); 
        glfwTerminate();
        return -1;
    }

    // Specify the viewport of openGL in the window
    glViewport(0, 0, WIDTH, HEIGHT);

    #pragma endregion

    #pragma region "Importation of shaders and textures, and creation and bind of buffers"

    Shader shader("res/shaders/defaultV.glsl", "res/shaders/defaultF.glsl");

    VAO VAO1;
    VAO1.Bind();

    VBO VBO1(vertices, sizeof(vertices));
    EBO EBO1(indices, sizeof(indices));

    VAO1.LinkVBO(VBO1, 0, 3, GL_FLOAT, 5 * sizeof(float), (void*)0);
    VAO1.LinkVBO(VBO1, 1, 2, GL_FLOAT, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    VAO1.Unbind();
    VBO1.Unbind();
    EBO1.Unbind();



    Texture tex("res/textures/texture.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
    tex.textUnit(shader, "tex0", 0);

    glEnable(GL_DEPTH_TEST);

    #pragma endregion

    Camera camera(WIDTH, HEIGHT, glm::vec3(0.0f, 0.0f, 2.0f), window);

    
    
    
    while (!glfwWindowShouldClose(window) && glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS)
    {
        // Specify the color of the background
        glClearColor(0.07f, 0.13f, 0.917f, 1.0f);
        // Clean the back buffer and assign the new color to it
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        camera.Inputs(window);
        camera.updateMatrix(45.0f, 0.1f, 10000.0f);

        shader.use();

        glUniform3f(glGetUniformLocation(shader.ID, "camPos"), camera.Position.x, camera.Position.y, camera.Position.z);
        camera.Matrix(shader, "camMatrix");

        tex.Bind();
        VAO1.Bind();

        glDrawElements(GL_TRIANGLES, sizeof(indices) / sizeof(int), GL_UNSIGNED_INT, 0);

        // Swap the back buffer with the front buffer
        glfwSwapBuffers(window);

        glfwPollEvents();
    }

    VAO1.Delete();
    VBO1.Delete();
    EBO1.Delete();
    shader.kill();

    tex.Delete();

    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}
